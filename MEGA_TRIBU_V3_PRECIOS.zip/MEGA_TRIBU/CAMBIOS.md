# Mega Tribu Hispana — V3 con precios

## Qué cambió respecto a la entrega anterior
- **Mismas correcciones de precios y bloqueo que Poseidón:** claves con o sin tilde, precio = entero positivo de Stars, y bloqueo por `PAYMENTS_ENABLED` + `BOT_INTEGRADO`. Todo queda bloqueado por defecto.
- **«Unirse» ahora exige elegir país primero** y manda `{accion:'unirse', pais, nivel}` al bot (por `sendData`, solo desde un botón de teclado del bot). No pide ni guarda datos personales.
- Los 3 niveles de talento también esperan a `BOT_INTEGRADO` y muestran "Disponible próximamente" mientras tanto.
- «Gratuito» muestra "Gratis".
- **Texto público sin jerga técnica**, y descripciones de los niveles de consumidor tomadas de la maqueta aprobada.
- Se quitó la maqueta de la página pública y la imagen sin uso. Peso: de 850 KB a unos 160 KB.
- Colores de la barra de Telegram, margen seguro del notch y reducción de movimiento.

## Cómo conectarlo con tu config real
Agrega `window.BOT_INTEGRADO = false;` a tu `poseidon_config.js` real y súbelo en lugar del de esta carpeta. Se pone en `true` solo cuando el bot ya lea los datos de la Mini App.

## V3 — Precios de lanzamiento y normales (por 30 días de acceso)
| Nivel | Lanzamiento | Normal (desde 2027-02-01, hora de Lima) | Lo que paga el comprador (≈ US$0.02 por Star) | Lo que recibes (≈ US$0.013 por Star) |
|---|---|---|---|---|
| Gratuito | Gratis | Gratis | — | — |
| Estándar | 175 ⭐ | 250 ⭐ | ≈ US$3.5 → US$5 | ≈ US$2.3 → US$3.3 |
| Premium | 420 ⭐ | 600 ⭐ | ≈ US$8.4 → US$12 | ≈ US$5.5 → US$7.8 |
| VIP | 1050 ⭐ | 1500 ⭐ | ≈ US$21 → US$30 | ≈ US$13.7 → US$19.5 |

- El precio de lanzamiento es ~30 % menor que el normal. El cambio ocurre solo, a las 00:00 de Lima del 1 de febrero de 2027.
- Todo vive en `poseidon_config.js` (`POSEIDON_PRICES`, `POSEIDON_PRICES_NORMAL`, `PRECIO_NORMAL_DESDE`). Para mover la fecha o subir un precio, cambias ahí y en `config/.env`.
- Si la fecha es inválida, la página muestra el precio normal. Si no hay precios normales, muestra el único que exista.
- **La página solo muestra.** El monto que se cobra lo decide el bot. Hasta que el bot lea esos mismos precios y la misma fecha, no habilites `PAYMENTS_ENABLED`.
- Los precios en dólares son estimaciones con tasas publicadas por terceros; Telegram puede cambiarlas y el comprador paga distinto según dónde compre sus Stars. Confirma en tu panel de Telegram.

## Pendiente (no declarar terminado)
- Que el bot reciba la solicitud, verifique `initData` en el servidor y la edad (+18), y haga el alta.
- Fotos con licencia comprobada para los otros 20 países.
- Contenido de los niveles 2 y 3: revisa las reglas de Telegram sobre contenido privado opcional antes de cobrar nada.
- Probar en Telegram real. Yo solo lo validé con pruebas de código, no con un navegador.
